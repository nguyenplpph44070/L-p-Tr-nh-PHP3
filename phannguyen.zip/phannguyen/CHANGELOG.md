# Release Notes

## [Unreleased](https://github.com/laravel/laravel/compare/v9.5.1...10.x)

## [v10.0.0 (2022-02-07)](https://github.com/laravel/laravel/compare/v9.5.1...10.x)

Laravel 10 includes a variety of changes to the application skeleton. Please consult the diff to see what's new.
